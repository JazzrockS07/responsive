<?php

class CORE {
	static $CREATED 	= 2012;
	static $SKIN 		= 'default';
	static $CONT		= 'modules';
	static $DOMAIN 		= 'http://jazzrock.school-php.com';
	static $JS 			= array();
	static $CSS 		= array();
	static $META 		= array(
		'title' => 'стандартный TITLE',
		'description' => 'd',
		'keywords' => 'k'
	);
}

